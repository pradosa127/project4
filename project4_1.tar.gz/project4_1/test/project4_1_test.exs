defmodule Project41Test do
  use ExUnit.Case
  doctest Project41

  test "greets the world" do
    assert Project41.hello() == :world
  end
end
